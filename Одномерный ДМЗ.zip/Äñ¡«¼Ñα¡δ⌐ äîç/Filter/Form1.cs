﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using Troschuetz;
using Troschuetz.Random;
using Matrix_dll;

namespace Filter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();          
            timer1.Tick += new EventHandler(timer1_Tick);
        }

        void load_data()
        {
            M = new List<int>();
            M.Add(Convert.ToInt32(textBox8.Text));
            Mm = new List<int>();
            Mm.Add(Convert.ToInt32(textBox8.Text));
            //M.Add(Convert.ToInt32(textBox8.Text));
            lambda_ = 10;
            t0 = Convert.ToDouble(textBox9.Text);
            T = Convert.ToDouble(textBox10.Text);
            h = Convert.ToDouble(textBox7.Text);
            progressBar1.Maximum = Convert.ToInt32((T - t0) / h);
            //I = 1; J = 0;     
            dzeta= Convert.ToDouble(textBox4.Text);
            sigma= Convert.ToDouble(textBox3.Text);            
        }

        //Initial conditions        
        List<int> M,Mm,obr,vetv;
        double h, lambda_ , t0, T, sigma, dzeta,eps,ck;
        List<List<double>>   X_k, F_k;
        List<double> Xi, X, X_true, Xk, t_, h_i, tau, X_tild, phi, ksi, mu, psi, epsilon, kal_err;
        //double[][]
        List<double> Y;
        List<double> Z;
        List<double> t;
        //double[] X_tild;
       
        int I, J, o, v;
        //

        //Multidimension stats
        double[][] State;
        double[][] W;
        double[][] Dimension;
        double[][] V;
        int n = 3, m = 2, s = 1;
        
        //Epsilon
        List<double> mistake = new List<double>();
        List<double> MO = new List<double>();
        List<double> CK = new List<double>();
        List<double> max_eps = new List<double>();
        List<double> mist_kal = new List<double>();
        List<double> max_kal = new List<double>();
        List<List<double>> eps_arr = new List<List<double>>();
        List<List<double>> kal_arr = new List<List<double>>();

        NormalDistribution ddd = new NormalDistribution();

        List<double> generate_X(int n)
        {
            Random r = new Random(DateTime.Now.Millisecond);
            List<double> ret = new List<double>();

            ddd.Mu = 0.2; ddd.Sigma = 0.01;
            //ddd.Mu = -0.5; ddd.Sigma = 0.1;

            for (int i = 0; i < n; i++)
                ret.Add(ddd.NextDouble());
            return ret;
        }
        double generate_X()
        {
            Random r = new Random(DateTime.Now.Millisecond);
        
            ddd.Mu = 0.2; ddd.Sigma = 0.01;
            //ddd.Mu = -0.5; ddd.Sigma = 0.1;

            
            return  ddd.NextDouble();
        }

        ContinuousUniformDistribution dd = new ContinuousUniformDistribution();

        double uniform(double a, double b)
        {
            dd.Alpha = a; dd.Beta = b;
            return dd.NextDouble();
        }

        int k;
        void step_1()
        {
            //t0 = 0; T = 1;            

            X = new List<double>();//якобы оптимальный фильтр
            X.Add(generate_X());
            Xk = new List<double>();

            //X = new List<double[]>(); X.Add(new double[MM]);
            X_k = new List<List<double>>();

            //for (int i = 0; i < M[k]; i++)
            {
                X_k.Add(generate_X(M[k]));
                X_k.Add(generate_X(M[k]));

            }
            X_true = new List<double>();
            X_true.Add(generate_X());
            //X_true.Add(0);
            /*List<double> tt = new List<double>();
            for (int i = 0; i < M[k]; i++)
                {
                    tt.Add(X_true[0]);
                }
            X_k.Add(tt);
            X_k.Add(tt);*/
            
            Xi =  new List<double>();
            for (int i = 0; i < M[k]; i++)
            {
                double beta = uniform(0, 1);
                Xi.Add(-Math.Log(beta) / lambda_);
            }

            /*double[] FF = new double[MM];
            F = new List<double[]>();
            for (int i = 0; i < MM; i++)
                FF[i] = 1;
            F.Add(FF);*/
            F_k =  new List<List<double>>();
            List<double> tmp=new List<double>();
            for (int i = 0; i < M[k]; i++)
            {
                tmp.Add(1);
            }
            F_k.Add(tmp);
            //F_k.Add(tmp);

            t = new List<double>();
            t.Add(t0);
            //t[0] = t0;

            tau =  new List<double>();//comp alg
            h_i =  new List<double>();//comp alg
            X_tild = new List<double>();//comp alg

            obr = new List<int>();
            vetv = new List<int>();

            phi = new List<double>();
            ksi = new List<double>();
            mu = new List<double>();
            psi = new List<double>();
            phi.Add(0); ksi.Add(0); mu.Add(0); psi.Add(0);
            

            t_ = new List<double>();
            for (int i = 0; i < M[k]; i++)
            { t_.Add(t0); tau.Add(t0); h_i.Add(h); X_tild.Add(0);  }
            //t_.Add(t0);

            

            //M = new List<double>();
            //M.Add(MM);
            Z = new List<double>();
            Y = new List<double>();
            Y.Add(0);
            k = 0;
            step = 2;
           // step_2();
                          
        }
        
        int step = -1;
        void step_2()
        {
            int Mk = 0;
            for (int i = 0; i < F_k[k].Count; i++)
                Mk += (int)F_k[k][i];
            Mm.Add(Mk);
            //M.Add(Mk);

            List<double> tmp = new List<double>();
            
            for (int i = 0; i < F_k[k].Count; i++)//forming F[k+1]
            {
                tmp.Add(F_k[k][i]);
            } 
            F_k.Add(tmp);

            if (k >= 1) 
                F_k[k - 1].Clear();

            //Xk.Add(generate_X());
            double Xk_ = 0;
            for (int i = 0; i < M[k]; i++)
                if (F_k[k][i] == 1) Xk_ += X_k[k][i];
            Xk_ *= (double)1 / Mm[k];
            Xk.Add(Xk_);

            State = new double[n][];
            if (0 < T - t[k] && T - t[k] < h)
                h = T - t[k];
            if (T - t[k] == 0)
            
{
                
                for (int i = 0; i < State.Length; i++)
                {
                    State[i] = X_true.ToArray();
                }
                step = 0;//end();
            }

            X_true.Add(0);
            //X.Add(new double[MM]);
            //F.Add(new double[MM]);
            t.Add(0);            
                X_true[k + 1] = X_true[k] + h * f(t[k], X_true[k]) + Math.Sqrt(h) * sigma * delta_W();
                Z.Add(0);
                Z[k] = c(t[k], X_true[k]) + dzeta / Math.Sqrt(h) * delta_V();
                Y.Add(0);
                Y[k + 1] = Y[k] + h * Z[k];
            
            I = 1; J = 0;
            v = 0; o = 0;
            //if (M[k] == 1) step = 0;
            
            if (step != 0)
                step = 3;
            
            //step_3();
        }
        

        double c(double t, double X)
        {
            return X;
            //return Math.Sin(20 * t) * X;
        }
        
        double f(double t, double X)
        {
            return (10 * Math.Sin(100 * t) - 5) * X;
            //return 5 * Math.Sin(10 * t) ;
            //double res = (2 - 2 * Math.Cos(10 * t)) * X;
            //return (2 - 2 * Math.Cos(10 * t)) * X;
            //return res;
        }


        
        

        NormalDistribution d = new NormalDistribution();

        double delta_W()
        {
            //NormalDistribution d = new NormalDistribution();
            d.Mu = 0; d.Sigma = 1;
            return d.NextDouble();
        }
        double delta_V()
        {
            //NormalDistribution d = new NormalDistribution();
            d.Mu = 0; d.Sigma = 1;
            return d.NextDouble();
        }
        void step_3()
        {
            if (F_k[k][I] == 0)
            {
               // F_k[k + 1][I] = 0;
                step = 8;// step_8();  
            }
            else if (t_[I] + Xi[I] >= t[k] + h) step = 4;//step_4();
            else if (t_[I] + Xi[I] < t[k] + h) step = 5; //step_5();
            
        }
        void step_4()
        {
            
                X_k[k + 1][I] = X_k[k][I] + h * f(t[k], X_k[k][I]) + Math.Sqrt(h) * sigma* delta_W();
            
            F_k[k+1][I] = 1;            
            step = 8; //step_8();
        }
        void step_5()
        {
            double X_tilda = 0;
            double h_delta = t_[I] + Xi[I] - t[k];
            
                X_tilda = X_k[k][I] + h_delta * f(t[k], X_k[k][I]) + Math.Sqrt(h_delta) * sigma * delta_W();
            
            double alpha = uniform(0, 1);
            if (alpha <= (Math.Abs(lambda(t_[I] + Xi[I], X_tilda, Z[k])) / lambda_)) step_6(X_tilda, Z[k]);
            else step_7(X_tilda, Z[k]);            
        }

        double lambda(double t,double x, double z)
        {
            double res = c(t, x) * (1 / Math.Pow(dzeta, 2)) * (z - (1 / 2) * c(t, x));
            return res;
        }
        void step_6(double X_tilda, double Zk)
        {
            if (lambda(t_[I] + Xi[I], X_tilda, Zk) < 0)
            { F_k[k + 1][I] = 0; o++; step = 8;/*step_8();*/ }
            if (lambda(t_[I] + Xi[I], X_tilda, Zk) > 0)
            {
                J++; //M+J
                //resize(J);
                double h_delta = t_[I] + Xi[I] - t[k];
                double h_delta_ = h - h_delta;
                //X_k[k].Add(0); F_k[k].Add(0); 
                Xi.Add(0); t_.Add(0); 
                X_k[k+1].Add(0); F_k[k+1].Add(0);

                    X_k[k + 1][M[k] + J - 1] = X_tilda + h_delta_ * f(t[k] + h_delta, X_tilda) + Math.Sqrt(h_delta_) * sigma * delta_W();
                
                F_k[k + 1][M[k] + J-1] = 1;
                v++;
                /*for (int r = 0; r < k+1; r++)
                    F_k[r][M[k] + J - 1] = 0;*/

                t_[M[k] + J-1] = t_[I] + Xi[I];
                //t_[I] = t_[I] + Xi[I];
                do
                {
                    double beta = uniform(0, 1);
                    Xi[M[k] + J-1] = -Math.Log(beta) / lambda_;
                } while (t_[M[k] + J-1] + Xi[M[k] + J-1] <= t[k] + h);

                
                    X_k[k + 1][I] = X_tilda + h_delta_ * f(t[k] + h_delta, X_tilda) + Math.Sqrt(h_delta_) * sigma * delta_W();
                
                F_k[k + 1][I] = 1;
                t_[I] = t_[I] + Xi[I];
                do
                {
                    double beta = uniform(0, 1);
                    Xi[I] = -Math.Log(beta) / lambda_;
                } while (t_[I] + Xi[I] <= t[k] + h);
                
            }
            
            step = 8;//step_8();

        }

        /*void resize(int j)
        {

        }*/
        void step_7(double X_tilda, double Zk)
        {
            double h_delta = t_[I] + Xi[I] - t[k];
            double h_delta_ = h - h_delta;

            
                X_k[k + 1][I] = X_tilda + h_delta_ * f(t[k] + h_delta, X_tilda) + Math.Sqrt(h_delta_) * sigma * delta_W();
            
            F_k[k + 1][I] = 1;
            t_[I] = t_[I] + Xi[I];
            do
            {
                double beta = uniform(0, 1);
                Xi[I] = -Math.Log(beta) / lambda_;
            } while (t_[I] + Xi[I] <= t[k] + h);
            
            step = 8;// step_8();
        }
        void step_8()
        {            
            if (I == M[k]-1)
            {
                M.Add(M[k] + J-1);
                obr.Add(o); vetv.Add(v); phi.Add(0); ksi.Add(0); psi.Add(0); mu.Add(0);
                X_k.Add(generate_X(M[k + 1])); X_k[k].Clear(); t[k + 1] = t[k] + h; k++; 
                //J = 0;                 
                progressBar1.Increment(1);
                step = 2;/*step_2();*/
            }
            else if (I < M[k]-1)
            {
                I++; 
                //X_k[k + 1].Add(0); F_k[k + 1].Add(0); 
                step = 3;/*step_3();*/ }
            //else if (I > M[k] - 1) { I = M[k] - 1; }
        }

        
        //Complicated algorithm 

        void step_3c()
        {
            if (F_k[k][I] == 0)
            {
                // F_k[k + 1][I] = 0;
                step = 10;// step_8();  
            }
            else if (t_[I] + Xi[I] >= t[k] + h) step = 4;//step_4();
            else if (t_[I] + Xi[I] < t[k] + h) step = 5; //step_5();

        }
        void step_4c()
        {
            //X_k[k + 1].Add(0); F_k[k + 1].Add(0);
            
                X_k[k + 1][I] = X_k[k][I] + h * f(t[k], X_k[k][I]) + Math.Sqrt(h) * sigma * delta_W();
            
            F_k[k + 1][I] = 1;
            step = 10; //step_8();
        }

        void step_5c()
        {                   
            if (t_[I] + Xi[I] >= t[k] + h)
                step_9c(X_tild[I], Z[k]);
            else 
            {
                //X_tild = new List<double>; 
                X_tild[I] = X_k[k][I]; tau[I] = t[k]; 
                step = 6; 
            }
        }

        void step_6c()
        {            
            h_i[I] = t_[I] + Xi[I] - tau[I];            
            X_tild[I] = X_tild[I] + h_i[I] * f(tau[I], X_tild[I]) + Math.Sqrt(h_i[I]) * sigma * delta_W();            
            tau[I] = tau[I] + h_i[I];
            double alpha = uniform(0, 1);
            if (alpha <= (Math.Abs(lambda(tau[I], X_tild[I], Z[k]))) / lambda_) step_7c(X_tild[I], Z[k]);
            else step_8c();  
        }

        void step_7c(double X_tilda, double Zk)
        {
            if (lambda(tau[I], X_tilda, Zk) < 0) { F_k[k + 1][I] = 0; o++; step = 10;/*step_10();*/ }
            if (lambda(tau[I], X_tilda, Zk) > 0)
            {
                J++; //M+J
                //resize(J);
                Xi.Add(0); t_.Add(0); tau.Add(0); h_i.Add(0);
                X_k[k + 1].Add(0); F_k[k + 1].Add(0); X_tild.Add(0);
                F_k[k + 1][M[k] + J - 1] = 1; v++;
                t_[M[k] + J-1] = t_[I] + Xi[I];
                X_tild[M[k] + J-1] = X_tilda;
                tau[M[k] + J-1] = tau[I];
                //do
                //{
                    double beta = uniform(0, 1);
                    Xi[M[k] + J-1] = -Math.Log(beta) / lambda_;
                //} while (t_[MM + J - 1] + Xi[MM + J - 1] < t[k] + h);
                    t_[I] = t_[I] + Xi[I];
                    double beta_1 = uniform(0, 1);
                    Xi[I] = -Math.Log(beta_1) / lambda_;
                    step = 5;
            }            
        }

        void step_8c()
        {
            t_[I] = t_[I] + Xi[I];
            double beta = uniform(0, 1);
            Xi[I] = -Math.Log(beta) / lambda_;
            step = 5;
        }

        void step_9c(double X_tild, double Zk)
        {
            h_i[I] = t[k] + h - tau[I] ;            
            X_k[k + 1][I] = X_tild + h_i[I] * f(tau[I], X_tild) + Math.Sqrt(h_i[I]) * sigma * delta_W();            
            F_k[k + 1][I] = 1;
            //t_[I] = t_[I] + Xi[I];   
            step = 10;
        }

        void step_10c()
        {
            if (I == M[k] + J-1)
            { M.Add(M[k] + J - 1); X_k.Add(generate_X(M[k + 1])); t[k + 1] = t[k] + h; obr.Add(o); vetv.Add(v); phi.Add(0); ksi.Add(0); psi.Add(0); mu.Add(0); k++; progressBar1.Increment(1); step = 2;/*step_2();*/ }
            else if (I < M[k] - 1)
            { I++; step = 3;/*step_3();*/ }
            else if (I < M[k] + J-1 && I >= M[k] - 1)
            { I++; X_k[k].Add(generate_X()); step = 5; }
        }

        //End

        /*double[] X_X;
        double[] XX;
        double[] K;*/
        double func(double t)
        {
              return (10 * Math.Sin(100 * t) - 5);
              //return (2 - 2 * Math.Cos(10 * t));
        }

        void finish()
        {            
            float hh = (float)1 / X_true.Count;
            chart1.Series.Add("X");
            chart1.Series.Add("Оптимальный фильтр");
            chart1.Series.Add("Y");
            chart1.Series.Add("Фильтр Калмана");
            chart1.Series["X"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            chart1.Series["Оптимальный фильтр"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            chart1.Series["Y"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            chart1.Series["Фильтр Калмана"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            chart1.Series["X"].Color = System.Drawing.Color.DarkCyan;
            chart1.Series["Оптимальный фильтр"].Color = System.Drawing.Color.DarkViolet;
            chart1.Series["Y"].Color = System.Drawing.Color.DarkRed;
            chart1.Series["Фильтр Калмана"].Color = System.Drawing.Color.DarkOrange;
            chart2.Series.Add("Траектории");
            chart2.Series["Траектории"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            chart2.Series["Траектории"].Color = System.Drawing.Color.Magenta;
            chart1.ChartAreas[0].AxisX.Minimum =chart2.ChartAreas[0].AxisX.Minimum= 0;
            //chart2.Legends.Add("Траектории");
            //chart2.Legends["Траектории"].IsDockedInsideChartArea = false;
            //chart2.Series["M"].Legend = "Треактории";
            chart3.Series.Add("Обрывы");
            chart3.Series["Обрывы"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            chart3.Series["Обрывы"].Color = System.Drawing.Color.DarkOliveGreen;
            chart4.Series.Add("Ветвления");
            chart4.Series["Ветвления"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            chart4.Series["Ветвления"].Color = System.Drawing.Color.DarkOrange;
            chart3.ChartAreas[0].AxisX.Minimum = chart4.ChartAreas[0].AxisX.Minimum = 0;
            /*FileStream fs = new FileStream("vetv-obr.txt", FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine("Obr = \t Vetv =");*/
            int obrres=0, vetvres=0;
            for (int i = 0; i < Xk.Count - 1; i++)
            {
                obrres += obr[i];
                vetvres += vetv[i];
                chart3.Series["Обрывы"].Points.AddXY(Math.Round(i * hh, 2), (float)obrres);
                chart4.Series["Ветвления"].Points.AddXY(Math.Round(i * hh, 2), (float)vetvres);
                //chart3.Series["Обрывы"].Points.AddXY(Math.Round(i * hh, 2), (float)obr[i]);
                //chart4.Series["Ветвления"].Points.AddXY(Math.Round(i * hh, 2), (float)vetv[i]);
                //sw.WriteLine(obr[i]+ "\t" + vetv[i]);
            }
            //sw.Close();

            FileStream fs = new FileStream("X.txt", FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);

            FileStream ffs = new FileStream("lambda.txt", FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter ssw = new StreamWriter(ffs);

            timer1.Enabled = true;            
            for (int i = 0; i < Y.Count - 1; i++)
            {
                chart1.Series["Y"].Points.AddXY(Math.Round(i * hh, 2), (float)Y[i]);
            }
            double[] X_X = new double[X_true.Count];
            double[] X = new double[X_true.Count];
            double[] K = new double[X_true.Count];
            X_X[0] = X_true[0];
            X[0]=generate_X();
            K[0] = 1;
            double lam = 0;
            for (int i = 0; i < X_true.Count - 1; i++)
            {                
                K[i + 1] = K[i] + (t[i + 1] - t[i]) * (2 * func(t[i]) * K[i] + 1 - K[i] * K[i]);
                X_X[i + 1] = X_X[i] + (t[i + 1] - t[i]) * (func(t[i])*X_X[i]+K[i]*(Z[i]-X_X[i]));
                chart1.Series["Фильтр Калмана"].Points.AddXY(Math.Round(i * hh, 2), (float)X_X[i]);
                //X[i + 1] = X[i] + (t[i + 1] - t[i]) * (f(t[i],X[i])+sigma(t[i],X[i])*delta_W());
                chart1.Series["X"].Points.AddXY(Math.Round(i * hh, 2), (float)X_true[i]);
                sw.WriteLine(X_true[i]);
                ssw.WriteLine(lambda(t[i],Z[i],X_true[i]));
                lam += lambda(t[i], Z[i], X_true[i]);
            }
            lam /= X_true.Count;
            ssw.WriteLine("Лямбда*="+lam);
            sw.Close();
            ssw.Close();
            eps=0;
            epsilon = new List<double>();
            kal_err = new List<double>();
            for (int i = 0; i < X_true.Count - 1; i++)
            {
                epsilon.Add(X_true[i] - Xk[i]);
                kal_err.Add(X_true[i] - X_X[i]);
                eps += X_true[i] - Xk[i];
            }
            eps_arr.Add(epsilon);
            kal_arr.Add(kal_err);
            eps /= X_true.Count;
            for (int i = 0; i < X_true.Count - 1; i++)
            {
                ck += Math.Pow(X_true[i] - eps,2);
            }
            ck /= X_true.Count;
            if (Math.Abs(kal_err.Min()) > kal_err.Max()) mist_kal.Add(Math.Abs(kal_err.Min()));
            else mist_kal.Add(kal_err.Max());
            if (Math.Abs(epsilon.Min()) > epsilon.Max()) mistake.Add(Math.Abs(epsilon.Min()));
            else mistake.Add(epsilon.Max());
            MO.Add(eps);
            CK.Add(ck);
            float q =(float) 1 / k;
            for (int i = 0; i < M.Count - 1; i++)
            {
                chart2.Series["Траектории"].Points.AddXY(Math.Round(i * q, 2), (float)Mm[i]);
            } 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            /*for (int i = 0; i < State.Length; i++)
            {
                for (int j = 0; j < State[i].Length; j++)
                {
                    textBox2.Text += Convert.ToString(State[j][i] + " ");
                }
            }*/
            if (checkBox1.Checked == false)
            {
                load_data();
                chart1.Series.Clear();
                chart2.Series.Clear();
                chart3.Series.Clear();
                chart4.Series.Clear();
                progressBar1.Value = 0;
                k = 0;
                step = 1;//step_1();
                //if (k > 9) finish();
                if (comboBox1.Text == "Метод Эйлера-Маруямы")
                {
                    do
                    {


                        if (step == 1) step_1();
                        else if (step == 2) step_2();
                        else if (step == 3) step_3();
                        else if (step == 4) step_4();
                        else if (step == 5) step_5();
                        //else if (step == 7) step_7();
                        else if (step == 8) step_8();
                        else if (step == 0) finish();
                    } while (step != 0);
                    finish();
                }
                if (comboBox1.Text == "Модифицированный метод Эйлера")
                {
                    do
                    {


                        if (step == 1) step_1();
                        else if (step == 2) step_2m();
                        else if (step == 3) step_3();
                        else if (step == 4) step_4m();
                        else if (step == 5) step_5m();
                        //else if (step == 7) step_7();
                        else if (step == 8) step_8();
                        else if (step == 0) finish();
                    } while (step != 0);
                    finish();
                }
                if (comboBox1.Text == "Метод Хьюна")
                {
                    do
                    {
                        if (step == 1) step_1();
                        else if (step == 2) step_2h();
                        else if (step == 3) step_3();
                        else if (step == 4) step_4h();
                        else if (step == 5) step_5h();
                        //else if (step == 7) step_7();
                        else if (step == 8) step_8();
                        else if (step == 0) finish();
                    } while (step != 0);
                    finish();
                }
                if (comboBox1.Text == "Метод Рунге-Кутты")
                {
                    do
                    {


                        if (step == 1) step_1();
                        else if (step == 2) step_2r();
                        else if (step == 3) step_3();
                        else if (step == 4) step_4r();
                        else if (step == 5) step_5r();
                        //else if (step == 7) step_7();
                        else if (step == 8) step_8();
                        else if (step == 0) finish();
                    } while (step != 0);
                    finish();
                }
            }
            else button3_Click(sender, e);
        }
        int cc = 0;        
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (timer1.Enabled == true)
            {
                if (cc == X_true.Count - 1)
                {
                    cc = 0;
                    timer1.Enabled = false;
                    timer1.Interval = 20;                    
                }
                else
                {                    
                    float hh = (float)1 / Xk.Count;

                    //chart1.Series["X"].Points.AddXY(Math.Round(cc * hh, 2), (float)State[(int)numericUpDown1.Value - 1][cc]);
                    chart1.Series["Оптимальный фильтр"].Points.AddXY(Math.Round(cc * hh, 2), (float)Xk[cc]);
                    cc++;
                }
            }
        }
          
        private void button3_Click(object sender, EventArgs e)
        {
            load_data();
            chart1.Series.Clear();
            chart2.Series.Clear();
            chart3.Series.Clear();
            chart4.Series.Clear();
            progressBar1.Value = 0;
            k = 0;
            step = 1;//step_1();
            if (comboBox1.Text == "Метод Эйлера-Маруямы")
            {
                do
                {
                    if (step == 1) step_1();
                    else if (step == 2) step_2();
                    else if (step == 3) step_3c();
                    else if (step == 4) step_4c();
                    else if (step == 5) step_5c();
                    else if (step == 6) step_6c();
                    else if (step == 8) step_8c();
                    else if (step == 10) step_10c();
                    else if (step == 0) finish();
                } while (step != 0);
                finish();
            }
            if (comboBox1.Text == "Модифицированный метод Эйлера")
            {
                do
                {
                    if (step == 1) step_1();
                    else if (step == 2) step_2m();
                    else if (step == 3) step_3c();
                    else if (step == 4) step_4mc();
                    else if (step == 5) step_5mc();
                    else if (step == 6) step_6mc();
                    else if (step == 8) step_8c();
                    else if (step == 10) step_10c();
                    else if (step == 0) finish();
                } while (step != 0);
                finish();
            }
            if (comboBox1.Text == "Метод Хьюна")
            {
                do
                {
                    if (step == 1) step_1();
                    else if (step == 2) step_2h();
                    else if (step == 3) step_3c();
                    else if (step == 4) step_4hc();
                    else if (step == 5) step_5hc();
                    else if (step == 6) step_6hc();
                    else if (step == 8) step_8c();
                    else if (step == 10) step_10c();
                    else if (step == 0) finish();
                } while (step != 0);
                finish();
            }
            if (comboBox1.Text == "Метод Рунге-Кутты")
            {
                do
                {


                    if (step == 1) step_1();
                    else if (step == 2) step_2r();
                    else if (step == 3) step_3c();
                    else if (step == 4) step_4rc();
                    else if (step == 5) step_5rc();
                    else if (step == 6) step_6rc();
                    else if (step == 8) step_8c();
                    else if (step == 10) step_10c();
                    else if (step == 0) finish();
                } while (step != 0);
                finish();
            }
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            chart1.Series.Remove(chart1.Series["X"]);
            chart1.Series.Add("X");
            chart1.Series["X"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            chart1.Series["X"].Color = System.Drawing.Color.DarkCyan;
            timer1.Enabled = true; 
        }

        void resize()
        {
            chart1.Width = chart2.Width = chart3.Width = chart4.Width = ActiveForm.Width * 443 / 949;
            chart1.Height = chart2.Height = chart3.Height = chart4.Height = Form1.ActiveForm.Height * 274 / 809;
            panel1.Width = Form1.ActiveForm.Width * 673 / 949;
            panel1.Height = Form1.ActiveForm.Height * 137 / 809;
            panel1.Top = chart2.Bottom + 10;
            chart2.Top = chart1.Bottom + 20;
            chart3.Left = chart1.Right + 21;
            chart4.Top = chart3.Bottom + 20;
            chart4.Left = chart2.Right + 21;
            button1.Left = button2.Left = button3.Left = panel1.Right + 71;
            button2.Top = panel1.Top;
            button3.Top = button2.Bottom + 10;
            button1.Top = button3.Bottom + 10;
            //Form1.ActiveForm.MaximumSize = Screen.PrimaryScreen.WorkingArea.Size;            
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            resize();            
            if (this.WindowState == FormWindowState.Maximized || this.WindowState == FormWindowState.Minimized || this.WindowState == FormWindowState.Normal) { resize(); }
        }           

        //Модифицированный метод Эйлера
        void step_2m()
        {
            int Mk = 0;
            for (int i = 0; i < F_k[k].Count; i++)
                Mk += (int)F_k[k][i];
            Mm.Add(Mk);
            //M.Add(Mk);

            List<double> tmp = new List<double>();

            for (int i = 0; i < F_k[k].Count; i++)
            {
                tmp.Add(F_k[k][i]);
            }
            F_k.Add(tmp);

            //Xk.Add(generate_X());
            double Xk_ = 0;
            for (int i = 0; i < M[k]; i++)
                if (F_k[k][i] == 1) Xk_ += X_k[k][i];
            Xk_ *= (double)1 / Mm[k];
            Xk.Add(Xk_);

            State = new double[n][];
            if (0 < T - t[k] && T - t[k] < h)
                h = T - t[k];
            if (T - t[k] == 0)
            {

                for (int i = 0; i < State.Length; i++)
                {
                    State[i] = X_true.ToArray();
                }
                step = 0;//end();
            }

            X_true.Add(0);
            t.Add(0);           
            phi[k] = h * f(t[k], X_true[k]) + Math.Sqrt(h) * sigma * delta_W();
            X_true[k + 1] = X_true[k] + h * f(t[k] + h / 2, X_true[k] + phi[k] / 2) + Math.Sqrt(h) * sigma * delta_W();
            Z.Add(0);
            ksi[k] = h * c(t[k], X_true[k]) + Math.Sqrt(h) * dzeta * delta_V();
            Z[k] = c(t[k] + h / 2, X_true[k] + ksi[k] / 2) + dzeta / Math.Sqrt(h) * delta_V();
            Y.Add(0);
            Y[k + 1] = Y[k] + h * Z[k];       
            I = 1; J = 0;
            v = 0; o = 0;
            //if (M[k] == 1) step = 0;

            if (step != 0)
                step = 3;

            //step_3();
        }
        void step_4m()
        {           
                phi[k] = h * f(t[k], X_k[k][I]) + Math.Sqrt(h) * sigma * delta_W();
                X_k[k + 1][I] = X_k[k][I] + h * f(t[k] + h / 2, X_k[k][I] + phi[k] / 2) + Math.Sqrt(h) * sigma * delta_W();
            
            F_k[k + 1][I] = 1;
            step = 8; //step_8();
        }
        void step_5m()
        {
            double X_tilda = 0;
            double h_delta = t_[I] + Xi[I] - t[k];            
            
                phi[k] = h_delta * f(t[k], X_k[k][I]) + sigma * delta_W();
                X_tilda = X_k[k][I] + h_delta * f(t[k] + h_delta / 2, X_k[k][I] + phi[k] / 2) + Math.Sqrt(h_delta) * sigma* delta_W();
            
            
            double alpha = uniform(0, 1);
            if (alpha <= (Math.Abs(lambda(t_[I] + Xi[I], X_tilda, Z[k])) / lambda_)) step_6m(X_tilda, Z[k]);
            else step_7m(X_tilda, Z[k]);
        }        
        void step_6m(double X_tilda, double Zk)
        {
            if (lambda(t_[I] + Xi[I], X_tilda, Zk) < 0)
            { F_k[k + 1][I] = 0; o++; step = 8;/*step_8();*/ }
            if (lambda(t_[I] + Xi[I], X_tilda, Zk) > 0)
            {
                J++; //M+J
                //resize(J);
                double h_delta = t_[I] + Xi[I] - t[k];
                double h_delta_ = h - h_delta;
                //X_k[k].Add(0); F_k[k].Add(0); 
                Xi.Add(0); t_.Add(0);
                X_k[k + 1].Add(0); F_k[k + 1].Add(0);
                
                    phi[k] = h_delta_ * f(t[k] + h_delta, X_tilda) + Math.Sqrt(h) * sigma * delta_W();
                    X_k[k + 1][M[k] + J - 1] = X_tilda + h_delta_ * f(t[k] + h_delta + h / 2, X_tilda + phi[k] / 2) + Math.Sqrt(h_delta_) * sigma * delta_W();                
                
                F_k[k + 1][M[k] + J - 1] = 1;
                v++;
                /*for (int r = 0; r < k+1; r++)
                    F_k[r][M[k] + J - 1] = 0;*/

                t_[M[k] + J - 1] = t_[I] + Xi[I];
                //t_[I] = t_[I] + Xi[I];
                do
                {
                    double beta = uniform(0, 1);
                    Xi[M[k] + J - 1] = -Math.Log(beta) / lambda_;
                } while (t_[M[k] + J - 1] + Xi[M[k] + J - 1] <= t[k] + h);
                
                    phi[k] = h_delta_ * f(t[k] + h_delta, X_tilda) + Math.Sqrt(h_delta_) * sigma * delta_W();
                    X_k[k + 1][I] = X_tilda + h_delta_ * f(t[k] + h_delta + h / 2, X_tilda + phi[k] / 2) + Math.Sqrt(h_delta_) * sigma * delta_W();                
                
                F_k[k + 1][I] = 1;
                t_[I] = t_[I] + Xi[I];
                do
                {
                    double beta = uniform(0, 1);
                    Xi[I] = -Math.Log(beta) / lambda_;
                } while (t_[I] + Xi[I] <= t[k] + h);

            }

            step = 8;//step_8();

        }
        void step_7m(double X_tilda, double Zk)
        {
            double h_delta = t_[I] + Xi[I] - t[k];
            double h_delta_ = h - h_delta;            
                phi[k] = h * f(t[k] + h_delta, X_tilda) + Math.Sqrt(h) * sigma * delta_W();
                X_k[k + 1][I] = X_tilda + h_delta_ * f(t[k] + h_delta + h / 2, X_tilda + phi[k] / 2) + Math.Sqrt(h) * sigma* delta_W();            
            
            F_k[k + 1][I] = 1;
            t_[I] = t_[I] + Xi[I];
            do
            {
                double beta = uniform(0, 1);
                Xi[I] = -Math.Log(beta) / lambda_;
            } while (t_[I] + Xi[I] <= t[k] + h);

            step = 8;// step_8();
        }

        //Метод Хьюна
        void step_2h()
        {
            int Mk = 0;
            for (int i = 0; i < F_k[k].Count; i++)
                Mk += (int)F_k[k][i];
            Mm.Add(Mk);
            //M.Add(Mk);

            List<double> tmp = new List<double>();

            for (int i = 0; i < F_k[k].Count; i++)
            {
                tmp.Add(F_k[k][i]);
            }
            F_k.Add(tmp);

            //Xk.Add(generate_X());
            double Xk_ = 0;
            for (int i = 0; i < M[k]; i++)
                if (F_k[k][i] == 1) Xk_ += X_k[k][i];
            Xk_ *= (double)1 / Mm[k];
            Xk.Add(Xk_);

            State = new double[n][];
            if (0 < T - t[k] && T - t[k] < h)
                h = T - t[k];
            if (T - t[k] == 0)
            {

                for (int i = 0; i < State.Length; i++)
                {
                    State[i] = X_true.ToArray();
                }
                step = 0;//end();
            }

            X_true.Add(0);
            //X.Add(new double[MM]);
            //F.Add(new double[MM]);
            t.Add(0);

                phi[k] = h * f(t[k], X_true[k]) + Math.Sqrt(h) * sigma * delta_W();
                X_true[k + 1] = X_true[k] + h * (f(t[k], X_true[k]) + f(t[k] + h, X_true[k] + phi[k])) / 2 + Math.Sqrt(h) * (sigma + sigma) * delta_W() / 2;
                Z.Add(0);
                ksi[k] = h * c(t[k], X_true[k]) + Math.Sqrt(h) * dzeta * delta_V();
                Z[k] = c(t[k] + h / 2, X_true[k] + ksi[k] / 2) + dzeta / Math.Sqrt(h) * delta_V();
                Y.Add(0);
                Y[k + 1] = Y[k] + h * Z[k];
            
            I = 1; J = 0;
            v = 0; o = 0;
            //if (M[k] == 1) step = 0;

            if (step != 0)
                step = 3;

            //step_3();
        }        
        void step_4h()
        {
            
                phi[k] = h * f(t[k], X_k[k][I]) + Math.Sqrt(h) * sigma * delta_W();
                X_k[k + 1][I] = X_k[k][I] + h * (f(t[k], X_k[k][I]) + f(t[k] + h, X_k[k][I] + phi[k])) / 2 + Math.Sqrt(h) * (sigma + sigma) * delta_W() / 2;
            
            F_k[k + 1][I] = 1;
            step = 8; //step_8();
        }
        void step_5h()
        {
            double X_tilda = 0;
            double h_delta = t_[I] + Xi[I] - t[k];
            
                phi[k] = h_delta * f(t[k], X_k[k][I]) + sigma * delta_W();
                X_tilda = X_k[k][I] + h_delta * (f(t[k], X_k[k][I]) + f(t[k] + h_delta, X_k[k][I] + phi[k])) / 2 + Math.Sqrt(h_delta) * (sigma + sigma) * delta_W() / 2;
            
            double alpha = uniform(0, 1);
            if (alpha <= (Math.Abs(lambda(t_[I] + Xi[I], X_tilda, Z[k])) / lambda_)) step_6h(X_tilda, Z[k]);
            else step_7h(X_tilda, Z[k]);
        }        
        void step_6h(double X_tilda, double Zk)
        {
            if (lambda(t_[I] + Xi[I], X_tilda, Zk) < 0)
            { F_k[k + 1][I] = 0; o++; step = 8;/*step_8();*/ }
            if (lambda(t_[I] + Xi[I], X_tilda, Zk) > 0)
            {
                J++; //M+J
                //resize(J);
                double h_delta = t_[I] + Xi[I] - t[k];
                double h_delta_ = h - h_delta;
                //X_k[k].Add(0); F_k[k].Add(0); 
                Xi.Add(0); t_.Add(0);
                X_k[k + 1].Add(0); F_k[k + 1].Add(0);

                    phi[k] = h_delta_ * f(t[k] + h_delta, X_tilda) + Math.Sqrt(h_delta_) * sigma * delta_W();
                    X_k[k + 1][M[k] + J - 1] = X_tilda + h_delta_ * (f(t[k] + h_delta, X_tilda) + f(t[k] + h + h_delta, X_k[k][I] + phi[k])) / 2 + Math.Sqrt(h) * (sigma+ sigma) * delta_W() / 2;
                
                F_k[k + 1][M[k] + J - 1] = 1;
                v++;
                /*for (int r = 0; r < k+1; r++)
                    F_k[r][M[k] + J - 1] = 0;*/

                t_[M[k] + J - 1] = t_[I] + Xi[I];
                //t_[I] = t_[I] + Xi[I];
                do
                {
                    double beta = uniform(0, 1);
                    Xi[M[k] + J - 1] = -Math.Log(beta) / lambda_;
                } while (t_[M[k] + J - 1] + Xi[M[k] + J - 1] <= t[k] + h);

                
                    phi[k] = h_delta_ * f(t[k] + h_delta, X_tilda) + Math.Sqrt(h_delta_) * sigma * delta_W();
                    X_k[k + 1][I] = X_tilda + h_delta_ * (f(t[k] + h_delta, X_tilda) + f(t[k] + h + h_delta, X_k[k][I] + phi[k])) / 2 + Math.Sqrt(h_delta_) * (sigma + sigma) * delta_W() / 2;
                
                F_k[k + 1][I] = 1;
                t_[I] = t_[I] + Xi[I];
                do
                {
                    double beta = uniform(0, 1);
                    Xi[I] = -Math.Log(beta) / lambda_;
                } while (t_[I] + Xi[I] <= t[k] + h);

            }

            step = 8;//step_8();

        }
        void step_7h(double X_tilda, double Zk)
        {
            double h_delta = t_[I] + Xi[I] - t[k];
            double h_delta_ = h - h_delta;

            
                phi[k] = h * f(t[k] + h_delta, X_tilda) + Math.Sqrt(h) * sigma * delta_W();
                X_k[k + 1][I] = X_tilda + h_delta_ * (f(t[k] + h_delta, X_tilda) + f(t[k] + h + h_delta, X_k[k][I] + phi[k])) / 2 + Math.Sqrt(h) * (sigma + sigma) * delta_W() / 2;
            
            F_k[k + 1][I] = 1;
            t_[I] = t_[I] + Xi[I];
            do
            {
                double beta = uniform(0, 1);
                Xi[I] = -Math.Log(beta) / lambda_;
            } while (t_[I] + Xi[I] <= t[k] + h);

            step = 8;// step_8();
        }

        //Метод Рунге-Кутты
        void step_2r()
        {
            int Mk = 0;
            for (int i = 0; i < F_k[k].Count; i++)
                Mk += (int)F_k[k][i];
            Mm.Add(Mk);
            //M.Add(Mk);

            List<double> tmp = new List<double>();

            for (int i = 0; i < F_k[k].Count; i++)
            {
                tmp.Add(F_k[k][i]);
            }
            F_k.Add(tmp);

            //Xk.Add(generate_X());
            double Xk_ = 0;
            for (int i = 0; i < M[k]; i++)
                if (F_k[k][i] == 1) Xk_ += X_k[k][i];
            Xk_ *= (double)1 / Mm[k];
            Xk.Add(Xk_);

            State = new double[n][];
            if (0 < T - t[k] && T - t[k] < h)
                h = T - t[k];
            if (T - t[k] == 0)
            {

                for (int i = 0; i < State.Length; i++)
                {
                    State[i] = X_true.ToArray();
                }
                step = 0;//end();
            }

            X_true.Add(0);            
            t.Add(0);

            /*phi[k] = h * f(t[k], X_true[k]) + Math.Sqrt(h) * sigma * delta_W();
            X_true[k + 1] = X_true[k] + h * (f(t[k], X_true[k]) + f(t[k] + h, X_true[k] + phi[k])) / 2 + Math.Sqrt(h) * (sigma + sigma) * delta_W() / 2;
            Z.Add(0);
            ksi[k] = h * c(t[k], X_true[k]) + Math.Sqrt(h) * dzeta * delta_V();
            Z[k] = c(t[k] + h / 2, X_true[k] + ksi[k] / 2) + dzeta / Math.Sqrt(h) * delta_V();
            Y.Add(0);
            Y[k + 1] = Y[k] + h * Z[k];*/

                phi[k] = h * f(t[k], X_true[k]) + Math.Sqrt(h) * sigma * delta_W();
                mu[k] = h * f(t[k] + h, X_true[k] + phi[k]) + Math.Sqrt(h) * sigma * delta_W();
                X_true[k + 1] = X_true[k] + (phi[k] + mu[k]) / 2;
                Z.Add(0);
                ksi[k] = h * c(t[k], X_true[k]) + Math.Sqrt(h) * dzeta * delta_V();
                psi[k] = h * c(t[k] + h, X_true[k] + ksi[k]) + Math.Sqrt(h) * dzeta * delta_V();
                Z[k] = (ksi[k] + psi[k]) / (2*h);
                Y.Add(0);
                Y[k + 1] = Y[k] + h*Z[k];
            I = 1; J = 0;
            v = 0; o = 0;
            //if (M[k] == 1) step = 0;

            if (step != 0)
                step = 3;

            //step_3();
        }        
        void step_4r()
        {
            
                phi[k] = h * f(t[k], X_k[k][I]) + Math.Sqrt(h) * sigma * delta_W();
                mu[k] = h * f(t[k] + h, X_k[k][I] + phi[k]) + Math.Sqrt(h) * sigma * delta_W();
                X_k[k + 1][I] = X_k[k][I] + (phi[k] + mu[k]) / 2;
            
            F_k[k + 1][I] = 1;
            step = 8; //step_8();
        }
        void step_5r()
        {
            double X_tilda = 0;
            double h_delta = t_[I] + Xi[I] - t[k];
            
                phi[k] = h_delta * f(t[k], X_k[k][I]) + Math.Sqrt(h_delta) * sigma * delta_W();
                mu[k] = h_delta * f(t[k] + h_delta, X_k[k][I] + phi[k]) + Math.Sqrt(h_delta) * sigma * delta_W();
                X_tilda = X_k[k][I] + (phi[k] + mu[k]) / 2;
            
            double alpha = uniform(0, 1);
            if (alpha <= (Math.Abs(lambda(t_[I] + Xi[I], X_tilda, Z[k])) / lambda_)) step_6r(X_tilda, Z[k]);
            else step_7r(X_tilda, Z[k]);
        }        
        void step_6r(double X_tilda, double Zk)
        {
            if (lambda(t_[I] + Xi[I], X_tilda, Zk) < 0)
            { F_k[k + 1][I] = 0; o++; step = 8;/*step_8();*/ }
            if (lambda(t_[I] + Xi[I], X_tilda, Zk) > 0)
            {
                J++; //M+J
                //resize(J);
                double h_delta = t_[I] + Xi[I] - t[k];
                double h_delta_ = h - h_delta;
                //X_k[k].Add(0); F_k[k].Add(0); 
                Xi.Add(0); t_.Add(0);
                X_k[k + 1].Add(0); F_k[k + 1].Add(0);
                    phi[k] = h_delta_ * f(t[k], X_k[k][I]) + Math.Sqrt(h_delta) * sigma * delta_W();
                    mu[k] = h_delta_ * f(t[k] + h_delta, X_k[k][I] + phi[k]) + Math.Sqrt(h_delta_) * sigma * delta_W();
                    X_k[k + 1][M[k] + J - 1] = X_tilda + (phi[k] + mu[k]) / 2;
                
                F_k[k + 1][M[k] + J - 1] = 1;
                v++;
                /*for (int r = 0; r < k+1; r++)
                    F_k[r][M[k] + J - 1] = 0;*/

                t_[M[k] + J - 1] = t_[I] + Xi[I];
                //t_[I] = t_[I] + Xi[I];
                do
                {
                    double beta = uniform(0, 1);
                    Xi[M[k] + J - 1] = -Math.Log(beta) / lambda_;
                } while (t_[M[k] + J - 1] + Xi[M[k] + J - 1] <= t[k] + h);

                
                    phi[k] = h_delta_ * f(t[k], X_k[k][I]) + Math.Sqrt(h_delta) * sigma * delta_W();
                    mu[k] = h_delta_ * f(t[k] + h_delta, X_k[k][I] + phi[k]) + Math.Sqrt(h_delta_) * sigma * delta_W();
                    X_k[k + 1][I] = X_tilda + (phi[k] + mu[k]) / 2;
                
                F_k[k + 1][I] = 1;
                t_[I] = t_[I] + Xi[I];
                do
                {
                    double beta = uniform(0, 1);
                    Xi[I] = -Math.Log(beta) / lambda_;
                } while (t_[I] + Xi[I] <= t[k] + h);

            }

            step = 8;//step_8();

        }
        void step_7r(double X_tilda, double Zk)
        {
            double h_delta = t_[I] + Xi[I] - t[k];
            double h_delta_ = h - h_delta;

                phi[k] = h_delta_ * f(t[k], X_k[k][I]) + Math.Sqrt(h_delta) * sigma * delta_W();
                mu[k] = h_delta_ * f(t[k] + h_delta, X_k[k][I] + phi[k]) + Math.Sqrt(h_delta_) * sigma * delta_W();
                X_k[k + 1][I] = X_tilda + (phi[k] + mu[k]) / 2;
            
            F_k[k + 1][I] = 1;
            t_[I] = t_[I] + Xi[I];
            do
            {
                double beta = uniform(0, 1);
                Xi[I] = -Math.Log(beta) / lambda_;
            } while (t_[I] + Xi[I] <= t[k] + h);

            step = 8;// step_8();
        }

        //Модифицированный метод Эйлера 2        
        void step_4mc()
        {         
                phi[k] = h * f(t[k], X_k[k][I]) + Math.Sqrt(h) * sigma * delta_W();
                X_k[k + 1][I] = X_k[k][I] + h * f(t[k] + h / 2, X_k[k][I] + phi[k] / 2) + Math.Sqrt(h) * sigma * delta_W();            
            F_k[k + 1][I] = 1;
            step = 10; //step_8();
        }
        void step_5mc()
        {
            if (t_[I] + Xi[I] >= t[k] + h)
                step_9mc(X_tild[I], Z[k]);
            else
            {
                //X_tild = new List<double>; 
                X_tild[I] = X_k[k][I]; tau[I] = t[k];
                step = 6;
            }
        }
        void step_6mc()
        {
            h_i[I] = t_[I] + Xi[I] - tau[I];
            
                phi[k] = h_i[I] * f(tau[I], X_tild[I]) + sigma * delta_W();
                X_tild[I] = X_tild[I] + h_i[I] * f(tau[I] + h_i[I] / 2, X_tild[I] + phi[k] / 2) + Math.Sqrt(h_i[I]) * sigma * delta_W();
            
            tau[I] = tau[I] + h_i[I];
            double alpha = uniform(0, 1);
            if (alpha <= (Math.Abs(lambda(tau[I], X_tild[I], Z[k]))) / lambda_) step_7c(X_tild[I], Z[k]);
            else step_8c();
        }        
        void step_9mc(double X_tild, double Zk)
        {
            h_i[I] = t[k] + h - tau[I];
            
                phi[k] = h_i[I] * f(tau[I], X_tild) + sigma * delta_W();
                X_k[k + 1][I] = X_tild + h_i[I] * f(tau[I] + h_i[I] / 2, X_tild + phi[k] / 2) + Math.Sqrt(h_i[I]) * sigma * delta_W();
            
            F_k[k + 1][I] = 1;
            //t_[I] = t_[I] + Xi[I];   
            step = 10;
        }        
        //Метод Хьюна 2
        void step_4hc()
        {
           
                phi[k] = h * f(t[k], X_k[k][I]) + Math.Sqrt(h) * sigma * delta_W();
                X_k[k + 1][I] = X_k[k][I] + h * (f(t[k], X_k[k][I]) + f(t[k] + h, X_k[k][I] + phi[k])) / 2 + Math.Sqrt(h) * (sigma + sigma) * delta_W() / 2;                
            
            F_k[k + 1][I] = 1;
            step = 10; //step_8();
        }
        void step_5hc()
        {
            if (t_[I] + Xi[I] >= t[k] + h)
                step_9hc(X_tild[I], Z[k]);
            else
            {
                //X_tild = new List<double>; 
                X_tild[I] = X_k[k][I]; tau[I] = t[k];
                step = 6;
            }
        }
        void step_6hc()
        {
            h_i[I] = t_[I] + Xi[I] - tau[I];
            phi[k] = h_i[I] * f(tau[I], X_tild[I]) + sigma * delta_W();
            X_tild[I] = X_tild[I] + h_i[I] * (f(tau[I], X_tild[I]) + f(tau[I] + h_i[I], X_tild[I] + phi[k])) / 2 + Math.Sqrt(h_i[I]) * (sigma + sigma) * delta_W() / 2;            
            tau[I] = tau[I] + h_i[I];
            double alpha = uniform(0, 1);
            if (alpha <= (Math.Abs(lambda(tau[I], X_tild[I], Z[k]))) / lambda_) step_7c(X_tild[I], Z[k]);
            else step_8c();
        }
        void step_9hc(double X_tild, double Zk)
        {
            h_i[I] = t[k] + h - tau[I];
            phi[k] = h_i[I] * f(tau[I], X_tild) + sigma * delta_W();
            X_k[k + 1][I] = X_tild + h_i[I] * (f(tau[I], X_tild) + f(tau[I] + h_i[I], X_tild + phi[k])) / 2 + Math.Sqrt(h_i[I]) * (sigma + sigma) * delta_W() / 2;                
            F_k[k + 1][I] = 1;
            //t_[I] = t_[I] + Xi[I];   
            step = 10;
        }
        //Метод Рунге-Кутты 2
        void step_4rc()
        {
            //X_k[k + 1].Add(0); F_k[k + 1].Add(0);
            phi[k] = h * f(t[k], X_k[k][I]) + Math.Sqrt(h) * sigma * delta_W();
                mu[k] = h * f(t[k] + h, X_k[k][I] + phi[k]) + Math.Sqrt(h) * sigma * delta_W();
                X_k[k + 1][I] = X_k[k][I] + (phi[k] + mu[k]) / 2;
            F_k[k + 1][I] = 1;
            step = 10; //step_8();
        }
        void step_5rc()
        {
            if (t_[I] + Xi[I] >= t[k] + h)
                step_9rc(X_tild[I], Z[k]);
            else
            {
                //X_tild = new List<double>; 
                X_tild[I] = X_k[k][I]; tau[I] = t[k];
                step = 6;
            }
        }
        void step_6rc()
        {
            h_i[I] = t_[I] + Xi[I] - tau[I];
            phi[k] = h_i[I] * f(tau[I], X_tild[I]) + Math.Sqrt(h_i[I]) * sigma * delta_W();
            mu[k] = h_i[I] * f(tau[I] + h_i[I], X_tild[I] + phi[k]) + Math.Sqrt(h_i[I]) * sigma * delta_W();
            X_tild[I] = X_tild[I] + (phi[k] + mu[k]) / 2;                
            tau[I] = tau[I] + h_i[I];
            double alpha = uniform(0, 1);
            if (alpha <= (Math.Abs(lambda(tau[I], X_tild[I], Z[k]))) / lambda_) step_7c(X_tild[I], Z[k]);
            else step_8c();
        }
        void step_9rc(double X_tild, double Zk)
        {
            h_i[I] = t[k] + h - tau[I];
            phi[k] = h_i[I] * f(tau[I], X_tild) + Math.Sqrt(h_i[I]) * sigma * delta_W();
            mu[k] = h_i[I] * f(tau[I] + h_i[I], X_tild + phi[k]) + Math.Sqrt(h_i[I]) * sigma * delta_W();
            X_k[k + 1][I] = X_tild + (phi[k] + mu[k]) / 2;
            F_k[k + 1][I] = 1;
            //t_[I] = t_[I] + Xi[I];   
            step = 10;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //BackgroundWorker bg = new BackgroundWorker();
            //bg.DoWork();
            if (checkBox1.Checked == false)
            {
                progressBar2.Maximum = Convert.ToInt32(textBox11.Text);
                progressBar2.Value = 0;
                //BackgroundWorker bk = new BackgroundWorker();
                for (int i = 1; i <= Convert.ToInt32(textBox11.Text); i++)
                {
                    progressBar2.Increment(1);
                    //prbar();
                    button2_Click(sender, e);
                    max_eps.Add(mistake[i - 1]);
                    max_kal.Add(mist_kal[i - 1]);
                    //Application.DoEvents();
                    //progressBar2.Update();
                }
                List<double> E = new List<double>();
                List<double> E_k = new List<double>();
                FileStream Ef = new FileStream("Математическое ожидание.txt", FileMode.Create, FileAccess.Write);
                StreamWriter Ew = new StreamWriter(Ef);
                FileStream E_kf = new FileStream("Математическое ожидание ФК.txt", FileMode.Create, FileAccess.Write);
                StreamWriter E_kw = new StreamWriter(E_kf);
                for (int j = 0; j < t.Count() - 1; j++)
                {
                    double result = 0, reskal = 0;
                    for (int i = 0; i < eps_arr.Count(); i++)
                    {
                        result += eps_arr[i][j];
                        reskal += kal_arr[i][j];
                    }
                    E.Add(result / eps_arr.Count());
                    E_k.Add(reskal / kal_arr.Count());
                    Ew.WriteLine(E[j]);
                    E_kw.WriteLine(E_k[j]);
                }
                Ew.Close();
                E_kw.Close();
                List<double> Eck = new List<double>();
                List<double> Eck_k = new List<double>();
                FileStream Eckf = new FileStream("СК.txt", FileMode.Create, FileAccess.Write);
                StreamWriter Eckw = new StreamWriter(Eckf);
                FileStream Eck_kf = new FileStream("СК ФК.txt", FileMode.Create, FileAccess.Write);
                StreamWriter Eck_kw = new StreamWriter(Eck_kf);
                for (int j = 0; j < t.Count() - 1; j++)
                {
                    double resultck = 0, reskalck = 0;
                    for (int i = 0; i < eps_arr.Count(); i++)
                    {
                        resultck += Math.Pow(E[j] - eps_arr[i][j], 2);
                        reskalck += Math.Pow(E_k[j] - kal_arr[i][j], 2);
                    }
                    Eck.Add(resultck / eps_arr.Count());
                    Eck_k.Add(reskalck / kal_arr.Count());
                    Eckw.WriteLine(Eck[j]);
                    Eck_kw.WriteLine(Eck_k[j]);
                }
                Eckw.Close();
                Eck_kw.Close();
                /*FileStream mf = new FileStream("max_eps.txt", FileMode.Create, FileAccess.Write);
                StreamWriter mw = new StreamWriter(mf);
                for (int i = 0; i < max_eps.Count; i++)
                {
                    mw.WriteLine(max_eps[i]);
                }
                mw.Close();
                FileStream kf = new FileStream("kal_eps.txt", FileMode.Create, FileAccess.Write);
                StreamWriter kw = new StreamWriter(kf);
                for (int i = 0; i < max_kal.Count; i++)
                {
                    kw.WriteLine(max_kal[i]);
                }
                kw.Close();
                double res=0,res2=0;
                FileStream epsf = new FileStream("МО.txt", FileMode.Create, FileAccess.Write);
                StreamWriter epsw = new StreamWriter(epsf);
                for (int i = 0; i < MO.Count; i++)
                {
                    res += MO[i];
                    //epsw.WriteLine("Ошибка построения " + (i + 1) + "равна=" + MO[i]);
                    epsw.WriteLine(MO[i]);
                }
                FileStream ckf = new FileStream("CK.txt", FileMode.Create, FileAccess.Write);
                StreamWriter ckw = new StreamWriter(ckf);
                for (int i = 0; i < CK.Count; i++)
                {
                    res2 += CK[i];
                    //epsw.WriteLine("Ошибка построения " + (i + 1) + "равна=" + MO[i]);
                    ckw.WriteLine(CK[i]);
                }   
                epsw.Close();
                ckw.Close();*/
                FileStream ef = new FileStream("summary.txt", FileMode.Create, FileAccess.Write);
                StreamWriter ew = new StreamWriter(ef);
                double ss = 0, kk = 0;
                for (int i = 0; i < E.Count; i++)
                {
                    ss += E[i];
                    kk += E_k[i];
                }
                ss /= E.Count;
                kk /= E_k.Count;
                ew.WriteLine("Суммарная ошибка по МО равна=" + Math.Abs(ss));
                ew.WriteLine("Среднеквадратичная ошибка равна=" + kk);
                ew.Close();
                mistake.Clear();
                mist_kal.Clear();
                MO.Clear();
                CK.Clear();
                Error er = new Error();
                er.ShowDialog();
            }
            else
            {
                progressBar2.Maximum = Convert.ToInt32(textBox11.Text);
                progressBar2.Value = 0;

                for (int i = 1; i <= Convert.ToInt32(textBox11.Text); i++)
                {
                    progressBar2.Increment(1);
                    //prbar();
                    //bk.DoWork += bk_DoWork;
                    button3_Click(sender, e);
                    max_eps.Add(mistake[i - 1]);
                    max_kal.Add(mist_kal[i - 1]);
                }
                bk.RunWorkerAsync();
                List<double> E = new List<double>();
                List<double> E_k = new List<double>();
                FileStream Ef = new FileStream("Математическое ожидание.txt", FileMode.Create, FileAccess.Write);
                StreamWriter Ew = new StreamWriter(Ef);
                FileStream E_kf = new FileStream("Математическое ожидание ФК.txt", FileMode.Create, FileAccess.Write);
                StreamWriter E_kw = new StreamWriter(E_kf);
                for (int j = 0; j < t.Count() - 1; j++)
                {
                    double result = 0, reskal = 0;
                    for (int i = 0; i < eps_arr.Count(); i++)
                    {
                        result += eps_arr[i][j];
                        reskal += kal_arr[i][j];
                    }
                    E.Add(result / eps_arr.Count());
                    E_k.Add(Math.Abs(reskal / kal_arr.Count()));
                    Ew.WriteLine(E[j]);
                    E_kw.WriteLine(E_k[j]);
                }
                Ew.Close();
                E_kw.Close();
                List<double> Eck = new List<double>();
                List<double> Eck_k = new List<double>();
                FileStream Eckf = new FileStream("СК.txt", FileMode.Create, FileAccess.Write);
                StreamWriter Eckw = new StreamWriter(Eckf);
                FileStream Eck_kf = new FileStream("СК ФК.txt", FileMode.Create, FileAccess.Write);
                StreamWriter Eck_kw = new StreamWriter(Eck_kf);
                for (int j = 0; j < t.Count() - 1; j++)
                {
                    double resultck = 0, reskalck = 0;
                    for (int i = 0; i < eps_arr.Count(); i++)
                    {
                        resultck += Math.Pow(E[j] - eps_arr[i][j], 2);
                        reskalck += Math.Pow(E_k[j] - kal_arr[i][j], 2);
                    }
                    Eck.Add(resultck / eps_arr.Count());
                    Eck_k.Add(Math.Abs(reskalck / kal_arr.Count()));
                    Eckw.WriteLine(Eck[j]);
                    Eck_kw.WriteLine(Eck_k[j]);
                }
                Eckw.Close();
                Eck_kw.Close();
                FileStream ef = new FileStream("summary.txt", FileMode.Create, FileAccess.Write);
                StreamWriter ew = new StreamWriter(ef);
                ew.Close();
                mistake.Clear();
                mist_kal.Clear();
                MO.Clear();
                CK.Clear();
                Error er = new Error();
                er.ShowDialog();
            }
        }

        void prbar()
        {
            Application.DoEvents();
            progressBar2.Increment(1);
        }
        
BackgroundWorker bk = new BackgroundWorker();
        /*private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                progressBar2.Maximum = Convert.ToInt32(textBox11.Text);
                progressBar2.Value = 0;
                
                for (int i = 1; i <= Convert.ToInt32(textBox11.Text); i++)
                {                    
                    progressBar2.Increment(1);
                    //prbar();
                    //bk.DoWork += bk_DoWork;
                    button3_Click(sender, e);
                    max_eps.Add(mistake[i - 1]);
                    max_kal.Add(mist_kal[i - 1]);
                }
                bk.RunWorkerAsync();
                List<double> E = new List<double>();
                List<double> E_k = new List<double>();
                FileStream Ef = new FileStream("Математическое ожидание.txt", FileMode.Create, FileAccess.Write);
                StreamWriter Ew = new StreamWriter(Ef);
                FileStream E_kf = new FileStream("Математическое ожидание ФК.txt", FileMode.Create, FileAccess.Write);
                StreamWriter E_kw = new StreamWriter(E_kf);
                for (int j = 0; j < t.Count() - 1; j++)
                {
                    double result = 0, reskal = 0;
                    for (int i = 0; i < eps_arr.Count(); i++)
                    {
                        result += eps_arr[i][j];
                        reskal += kal_arr[i][j];
                    }
                    E.Add(result / eps_arr.Count());
                    E_k.Add(Math.Abs(reskal / kal_arr.Count()));
                    Ew.WriteLine(E[j]);
                    E_kw.WriteLine(E_k[j]);
                }
                Ew.Close();
                E_kw.Close();
                List<double> Eck = new List<double>();
                List<double> Eck_k = new List<double>();
                FileStream Eckf = new FileStream("СК.txt", FileMode.Create, FileAccess.Write);
                StreamWriter Eckw = new StreamWriter(Eckf);
                FileStream Eck_kf = new FileStream("СК ФК.txt", FileMode.Create, FileAccess.Write);
                StreamWriter Eck_kw = new StreamWriter(Eck_kf);
                for (int j = 0; j < t.Count() - 1; j++)
                {
                    double resultck = 0, reskalck = 0;
                    for (int i = 0; i < eps_arr.Count(); i++)
                    {
                        resultck += Math.Pow(E[j] - eps_arr[i][j], 2);
                        reskalck += Math.Pow(E_k[j] - kal_arr[i][j], 2);
                    }
                    Eck.Add(resultck / eps_arr.Count());
                    Eck_k.Add(Math.Abs(reskalck / kal_arr.Count()));
                    Eckw.WriteLine(Eck[j]);
                    Eck_kw.WriteLine(Eck_k[j]);
                }
                Eckw.Close();
                Eck_kw.Close();
                FileStream ef = new FileStream("summary.txt", FileMode.Create, FileAccess.Write);
                StreamWriter ew = new StreamWriter(ef);
                ew.Close();
                mistake.Clear();
                mist_kal.Clear();
                MO.Clear();
                CK.Clear();
                Error er = new Error();
                er.ShowDialog();
            }          

        }*/
        void bk_DoWork(object sender, DoWorkEventArgs e)
        {
            progressBar2.Increment(1);
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            
        }
    }
}
