﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Filter
{
    public partial class Error : Form
    {
        public Error()
        {
            InitializeComponent();            
        }


        private void Error_Load(object sender, EventArgs e)
        {
            List<double> er = new List<double>();
            List<double> er2 = new List<double>();
            List<double> erk = new List<double>();
            List<double> erk2 = new List<double>();
            /*using (var reader = new System.IO.StreamReader("МО.txt"))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    er.Add(Convert.ToDouble(line));
                }
            }*/
            //using (var reader = new System.IO.StreamReader("max_eps.txt"))
            using (var reader = new System.IO.StreamReader("Математическое ожидание.txt"))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    er.Add(Convert.ToDouble(line));
                }
            }
            using (var reader = new System.IO.StreamReader("Математическое ожидание ФК.txt"))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    erk.Add(Convert.ToDouble(line));
                }
            }
            using (var reader = new System.IO.StreamReader("СК.txt"))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    er2.Add(Convert.ToDouble(line));
                }
            }
            using (var reader = new System.IO.StreamReader("СК ФК.txt"))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    erk2.Add(Convert.ToDouble(line));
                }
            }
            chart1.Series.Add("МО ошибки оценивания");
            chart1.Series["МО ошибки оценивания"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            chart1.Series["МО ошибки оценивания"].Color = System.Drawing.Color.DarkOliveGreen;
            chart1.ChartAreas[0].AxisX.Minimum = 0;
            chart1.Series.Add("МО ошибки ФК");            
            chart1.Series["МО ошибки ФК"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            chart1.Series["МО ошибки ФК"].Color = System.Drawing.Color.Crimson;
            chart2.ChartAreas[0].AxisX.Minimum = 0;
            for (int i = 0; i < er.Count; i++)
            {
                //chart1.Series["МО ошибки"].Points.AddXY(i, (float)er[i]);
                chart1.Series["МО ошибки оценивания"].Points.AddXY((float)i / er.Count, (float)er[i]);
                chart1.Series["МО ошибки ФК"].Points.AddXY((float)i / erk.Count, (float)erk[i]);
            }
            chart2.Series.Add("СК ошибки");
            chart2.Series["СК ошибки"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            chart2.Series["СК ошибки"].Color = System.Drawing.Color.Tomato;
            chart2.Series.Add("СК ошибки ФК");
            chart2.Series["СК ошибки ФК"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            chart2.Series["СК ошибки ФК"].Color = System.Drawing.Color.LawnGreen;
            for (int i = 0; i < er2.Count; i++)
            {
                chart2.Series["СК ошибки"].Points.AddXY((float)i / er2.Count, (float)er2[i]);
                chart2.Series["СК ошибки ФК"].Points.AddXY((float)i / erk2.Count, (float)erk2[i]);
            }
        }
        void resize()
        {
            chart1.Width = chart2.Width  = Error.ActiveForm.Width * 558 / 1179;
            chart1.Height = chart2.Height = Error.ActiveForm.Height * 559 / 622;
            chart2.Left = chart1.Right + 39;      
        }
       
        private void Error_Resize_1(object sender, EventArgs e)
        {
            resize();
            if (this.WindowState == FormWindowState.Maximized || this.WindowState == FormWindowState.Minimized || this.WindowState == FormWindowState.Normal) { resize(); }
        }     
        
    }
}
